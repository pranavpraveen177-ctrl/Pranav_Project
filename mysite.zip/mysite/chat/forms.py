from django import forms
from.models import *
class RegisterForm(forms.ModelForm):
    class meta:
        model=Register
        fields=['username','email','password','image','phone_number']

class todolist(forms.ModelForm):
    class Meta:
        model = Todo
        fields = ['title']
