from django.shortcuts import render,redirect
from .models import *
from .forms import *

# Create your views here.
from django.http import HttpResponse
def chat(request):
    return HttpResponse("hello world")
def home_page(request):
    return render(request,'home.html')
def about(request):
    return render(request,'')
def register(request):
    # if request.method=='POST':
    #     u_name=request.POST['name']
    #     e_mail=request.POST['email']
    #     password=request.POST['password']
    #     Register.objects.create_user(
    #         username=u_name,email=e_mail,
    #         password=password,usertype='user')
    #     return redirect('/')
    form=RegisterForm(request.POST,request.FILES)
    if request.method=='POST':
        if form.is_valid():
            form.save
    return render(request,'register.html')
def Login(request):
    if request.method=='POST':
        username=request.POST('username')
        password=request.POST('password')
        user=authenticate(request,username,password=password)
        if user is not none:
            login(request,user)
            return redirect('/')
    return render(request,'login.html')


            
