from django.urls import path
from.import views
urlpatterns=[
    path('chat/',views.chat,name='chat'),
    path('',views.home_page,name='index'),
    path('about',views.about,name='about'),
    path('register',views.register,name='register'),
    path('list', views.task_list, name='task_list'),
    path('delete/<int:task_id>/', views.delete_task, name='delete_task'),
    

    ]